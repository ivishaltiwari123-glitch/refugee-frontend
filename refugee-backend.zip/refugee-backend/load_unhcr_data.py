"""
load_unhcr_data.py
==================
Loads UNHCR CSV files into Supabase.

Usage:
  pip install supabase python-dotenv
  python load_unhcr_data.py

Files needed in same folder:
  - csv          (UNHCR timeseries: data_date;individuals)
  - Population   (UNHCR demographics: date;month;year;male_total;female_total;...)
"""

import csv
import io
import os
from datetime import datetime
from dotenv import load_dotenv
from supabase import create_client, Client

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL", "https://jacwfkjkazqmspjdcysl.supabase.co")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY")  # Must be service_role key for writes

if not SUPABASE_SERVICE_KEY:
    print("ERROR: Set SUPABASE_SERVICE_KEY in your .env file")
    print("Get it from: Supabase Dashboard → Settings → API → service_role key")
    exit(1)

supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)


def clean_csv_bytes(filepath: str) -> str:
    """Remove null bytes from UTF-16 encoded UNHCR CSV files."""
    with open(filepath, "rb") as f:
        raw = f.read()
    return raw.replace(b"\x00", b"").decode("utf-8", errors="ignore")


def load_population_timeseries(filepath: str):
    """Load data_date;individuals timeseries into population_timeseries table."""
    print(f"\n📊 Loading population timeseries from: {filepath}")
    
    content = clean_csv_bytes(filepath)
    lines = content.split("\n")
    
    rows = []
    skipped = 0
    
    for line in lines:
        line = line.strip()
        # Skip header lines and metadata
        if not line or line.startswith("sep=") or line.startswith("data_date") or line.startswith('"'):
            continue
        
        parts = line.split(";")
        if len(parts) < 2:
            continue
        
        try:
            date_str = parts[0].strip()
            individuals = int(parts[1].strip())
            
            # Validate date format
            datetime.strptime(date_str, "%Y-%m-%d")
            
            rows.append({
                "data_date": date_str,
                "individuals": individuals
            })
        except (ValueError, IndexError):
            skipped += 1
            continue
    
    print(f"   Parsed {len(rows)} valid rows, skipped {skipped} invalid rows")
    
    # Upsert in batches of 100
    batch_size = 100
    inserted = 0
    
    for i in range(0, len(rows), batch_size):
        batch = rows[i:i + batch_size]
        result = supabase.table("population_timeseries").upsert(
            batch,
            on_conflict="data_date"
        ).execute()
        inserted += len(batch)
        print(f"   Inserted batch {i//batch_size + 1}: {inserted}/{len(rows)} rows")
    
    print(f"✅ Population timeseries: {inserted} rows loaded successfully")
    return inserted


def load_population_demographics(filepath: str):
    """Load demographics snapshot into population_demographics table."""
    print(f"\n👥 Loading population demographics from: {filepath}")
    
    content = clean_csv_bytes(filepath)
    lines = content.split("\n")
    
    rows = []
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith("sep=") or line.startswith("date") or line.startswith('"'):
            continue
        
        parts = line.split(";")
        if len(parts) < 7:
            continue
        
        try:
            rows.append({
                "snapshot_date":  parts[0].strip(),
                "month":          int(parts[1].strip()),
                "year":           int(parts[2].strip()),
                "male_total":     int(parts[3].strip()),
                "female_total":   int(parts[4].strip()),
                "children_total": int(parts[5].strip()),
                "uac_total":      int(parts[6].strip()),
            })
        except (ValueError, IndexError) as e:
            print(f"   Skipping invalid row: {line[:50]} — {e}")
            continue
    
    if rows:
        result = supabase.table("population_demographics").upsert(rows).execute()
        print(f"✅ Demographics: {len(rows)} row(s) loaded successfully")
        for row in rows:
            print(f"   Date: {row['snapshot_date']} | Male: {row['male_total']:,} | Female: {row['female_total']:,} | Children: {row['children_total']:,}")
    else:
        print("⚠️  No valid demographic rows found")
    
    return len(rows)


def load_ocha_hdx_data(api_key: str):
    """
    Fetch Syria displacement data from OCHA HDX API.
    Dataset: Syria locations of displacement
    """
    print(f"\n🌐 Fetching OCHA HDX data...")
    
    try:
        import requests
        
        headers = {"X-CKAN-API-Key": api_key}
        base_url = "https://data.humdata.org/api/3"
        
        # Search for Syria refugee datasets
        search_url = f"{base_url}/action/package_search"
        params = {
            "q": "syria refugees displacement camps",
            "fq": "organization:unhcr",
            "rows": 5
        }
        
        resp = requests.get(search_url, params=params, headers=headers, timeout=15)
        data = resp.json()
        
        if data.get("success"):
            results = data["result"]["results"]
            print(f"   Found {len(results)} datasets on HDX:")
            for r in results[:3]:
                print(f"   - {r['title']} ({r['name']})")
            
            # For now, insert known Syria camp locations from HDX
            # In production: download and parse the actual CSV resources
            known_camps = [
                {
                    "name": "Rukban Camp",
                    "zone": "Zone F",
                    "camp_type": "informal",
                    "population": 8000,
                    "capacity": 10000,
                    "lat": 33.7094,
                    "lng": 38.5644,
                    "location": f"SRID=4326;POINT(38.5644 33.7094)",
                    "source": "OCHA HDX",
                    "last_verified": datetime.now().date().isoformat()
                },
                {
                    "name": "Bab Al-Salam Camp",
                    "zone": "Zone G",
                    "camp_type": "formal",
                    "population": 15000,
                    "capacity": 20000,
                    "lat": 36.6167,
                    "lng": 37.0833,
                    "location": f"SRID=4326;POINT(37.0833 36.6167)",
                    "source": "OCHA HDX",
                    "last_verified": datetime.now().date().isoformat()
                }
            ]
            
            # Insert camps (skip location column - use lat/lng only since WKT insert needs raw SQL)
            camps_simple = [{k: v for k, v in c.items() if k != "location"} for c in known_camps]
            result = supabase.table("camp_locations").upsert(camps_simple).execute()
            print(f"✅ OCHA HDX: {len(known_camps)} camp locations added")
        else:
            print(f"⚠️  HDX API returned: {data.get('error', 'Unknown error')}")
            
    except ImportError:
        print("   Install requests: pip install requests")
    except Exception as e:
        print(f"   HDX fetch error: {e}")
        print("   Tip: Check your OCHA API key is valid")


def print_summary():
    """Print summary of what's now in Supabase."""
    print("\n" + "="*50)
    print("📋 DATABASE SUMMARY")
    print("="*50)
    
    tables = [
        ("population_timeseries", "Population data points"),
        ("population_demographics", "Demographics snapshots"),
        ("camp_locations", "Camp locations"),
        ("drone_flights", "Drone flights"),
        ("alerts", "Active alerts"),
        ("trucks", "Trucks"),
        ("resource_needs", "Resource need entries"),
    ]
    
    for table, label in tables:
        try:
            result = supabase.table(table).select("id", count="exact").execute()
            count = result.count if result.count else len(result.data)
            print(f"   {label:30s}: {count:>6} rows")
        except Exception as e:
            print(f"   {label:30s}: ERROR — {e}")
    
    print("="*50)


if __name__ == "__main__":
    print("🚀 REFUGEE CAMP GIS — UNHCR Data Loader")
    print("="*50)
    
    # Check if CSV files exist
    csv_file = "csv"
    pop_file = "Population"
    
    if os.path.exists(csv_file):
        load_population_timeseries(csv_file)
    else:
        print(f"⚠️  File '{csv_file}' not found — place it in the same folder as this script")
    
    if os.path.exists(pop_file):
        load_population_demographics(pop_file)
    else:
        print(f"⚠️  File '{pop_file}' not found — place it in the same folder as this script")
    
    # OCHA HDX
    ocha_key = os.getenv("OCHA_API_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJQYjlnaXdYZ1NrVkMybkZUbHNmZ3oyeE9tWklkSzFTLTNSUVdkSzNfZ2ZVIiwiaWF0IjoxNzcyMTA2NjY5LCJleHAiOjE3NzQ2OTg2Njl9.mJrEUQbKqNne4eizjXpRWrlrfD7Z_pVxiHEpMGVZjyg")
    if ocha_key:
        load_ocha_hdx_data(ocha_key)
    
    print_summary()
    print("\n✅ All done! Your Supabase database is populated.")
    print("   Next step: Run the FastAPI backend → python main.py")
